# errors.py

class InvalidInputError(Exception):
	pass