Python Training Notes
